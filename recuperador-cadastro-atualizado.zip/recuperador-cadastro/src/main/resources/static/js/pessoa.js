var RecuperadorCadastro = RecuperadorCadastro || {};

RecuperadorCadastro.RecuperarPessoa = (function() {

	function RecuperarPessoa() {

		this.btnBuscarHistorico   = $('.btn-buscar-pessoa-historico');
		this.btnSalvar            = $('.btn-salvar');
		this.formPessoa           = $('#form-pessoa');
		this.viewMensagemErro     = $('.div-mensagem-erro');
		this.mensagemErro         = $('.js-mensagem-erro');
		this.modalSucesso         = $('#sucesso');
		this.viewMensagemSucesso  = $('.div-mensagem-sucesso-modal');
		//this.mensagemGsurf        = $('.js-gsurf');
		//this.mensagemCadu         = $('.js-cadu');
		this.btnFechaModal        = $('.fecha-modal');
		this.viewCopyText         = $('.copy-text'); 
		this.inputCopyText        = $('#foo');
		this.idStelo              = $('#idStelo');

	}

	RecuperarPessoa.prototype.enable = function() {

		this.btnBuscarHistorico.on('click', onbtnBuscarHistorico.bind(this));
		this.btnSalvar.on('click', onbtnSalvar.bind(this));
		this.btnFechaModal.on('click', onBtnFechaModalClicado.bind(this));

	}

	function onbtnBuscarHistorico() {
        var url = this.formPessoa.attr('action');
        var id = $('#idStelo').val();
        console.log('idstelo', id)
        var resposta = $.ajax({
        	url: url,
        	method: 'GET',
        	data :{
        		id : id
        	}
        })
 
		resposta.done(onSucessoNaBusca.bind(this));
		resposta.fail(onErroAoBuscar.bind(this));
	}

	function onbtnSalvar() {
        var url = this.formPessoa.attr('action');
        var pessoaHistEntity = this.formPessoa.serialize();
        var radio = $('.r1').val();
        console.log(radio);
        var id = $('#idStelo').val();
        //var resposta = $.put(url, pessoaHistEntity);
        
        var resposta= $.ajax({
        	url: url,
        	method: 'PUT',
        	data :{
        		//pessoaHistEntity : pessoaHistEntity
        		id : id
        	}
        })

		resposta.done(onSucessoAoSalvar.bind(this));
		resposta.fail(onErroAoSalvar.bind(this));
	}

	function onSucessoNaBusca(pessoaHistEntity) {
		
		console('Passou aqui');

		//this.viewMensagemErro.addClass('hidden');
		//this.viewMensagemSucesso.removeClass('hidden');
		//this.mensagemCadu.text('Cadu: ' + pessoaHistEntity.cadu);
		//this.mensagemGsurf.text('GSurf: ' + pessoaHistEntity.gsurf)
		
		//if(pessoaHistEntity.message != null){
		//	this.viewCopyText.removeClass('hidden');			
		//	this.inputCopyText.val(pessoaHistEntity.message);
		//}
		//this.modalSucesso.modal();
	}

	function onErroAoBuscar(mensagemErro) {
		this.viewMensagemSucesso.addClass('hidden');
		this.viewMensagemErro.removeClass('hidden');
		this.mensagemErro.text(mensagemErro.responseText);
	}

	function onSucessoAoSalvar(pessoaHistEntity) {

		this.viewMensagemErro.addClass('hidden');
		this.viewMensagemSucesso.removeClass('hidden');
		//this.mensagemCadu.text('Cadu: ' + pessoaHistEntity.cadu);
		//this.mensagemGsurf.text('GSurf: ' + pessoaHistEntity.gsurf)
		
		//if(pessoaHistEntity.message != null){
			this.viewCopyText.removeClass('hidden');			
			this.inputCopyText.val('Sucesso na Recuperação da tabela Pessoa');
		//}
		this.modalSucesso.modal();
	}

	function onErroAoSalvar(mensagemErro) {
		this.viewMensagemSucesso.addClass('hidden');
		this.viewMensagemErro.removeClass('hidden');
		this.mensagemErro.text(mensagemErro.responseText);
	}

	function onBtnFechaModalClicado() {
		window.location.href = 'javascript:history.back()';
	}

	return RecuperarPessoa;

}());

$(function() {

	var recuperarPessoa = new RecuperadorCadastro.RecuperarPessoa();
	recuperarPessoa.enable();

});
