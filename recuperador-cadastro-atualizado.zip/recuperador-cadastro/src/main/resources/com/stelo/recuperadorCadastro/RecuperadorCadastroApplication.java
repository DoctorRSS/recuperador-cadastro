package com.stelo.recuperadorCadastro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecuperadorCadastroApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecuperadorCadastroApplication.class, args);
	}
}
