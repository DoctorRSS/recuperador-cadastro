package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaFisicaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaFisicaRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class PessoaFisicaService {

	@Autowired
	private PessoaFisicaRepository pessoaFisicaRepository;
	
	@Autowired
	private PessoaFisicaHistRepository pessoaFisicaHistRepository;

	public PessoaFisicaService() {
		// TODO Auto-generated constructor stub
	}

	@GetMapping
	public List<PessoaFisicaHistEntity> buscar(Long idStelo) {
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaFisicaHistEntity> listaPessoaFisicaHist = 
				pessoaFisicaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaPessoaFisicaHist;
	}
	
	@PutMapping
	public void salvar(PessoaFisicaHistEntity pessoaFisicaHistEntity) throws ObjetoNuloException {
		PessoaFisicaEntity pessoaFisicaEntity;
		try {
			pessoaFisicaEntity = construirPessoaFisica(pessoaFisicaHistEntity);
			pessoaFisicaRepository.save(pessoaFisicaEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}

	private PessoaFisicaEntity construirPessoaFisica(PessoaFisicaHistEntity pessoaFisicaHistEntity) throws ObjetoNuloException {
		PessoaFisicaEntity pessoaFisicaEntity = new PessoaFisicaEntity();
		if(pessoaFisicaHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de pessoa física para Alteração!");
		
		pessoaFisicaEntity.setCidadeNascimento(pessoaFisicaHistEntity.getCidadeNascimento());
		pessoaFisicaEntity.setCpf(pessoaFisicaHistEntity.getCpf());
		pessoaFisicaEntity.setDsNacionalidade(pessoaFisicaHistEntity.getDsNacionalidade());
		pessoaFisicaEntity.setDtAlteracao(pessoaFisicaHistEntity.getDtAlteracao());
		pessoaFisicaEntity.setDtInclusao(pessoaFisicaHistEntity.getDtInclusao());
		pessoaFisicaEntity.setDtNascimento(pessoaFisicaHistEntity.getDtNascimento());
		pessoaFisicaEntity.setEstadoNascimento(pessoaFisicaHistEntity.getEstadoNascimento());
		pessoaFisicaEntity.setFilhos(pessoaFisicaHistEntity.getFilhos());
		pessoaFisicaEntity.setIdEstadoCivilDm(pessoaFisicaHistEntity.getIdEstadoCivilDm());
		pessoaFisicaEntity.setIdFonteDadosCidadeNascimento(pessoaFisicaHistEntity.getIdFonteDadosCidadeNascimento());
		pessoaFisicaEntity.setIdFonteDadosCpfDm(pessoaFisicaHistEntity.getIdFonteDadosCpfDm());
		pessoaFisicaEntity.setIdFonteDadosDataNascimento(pessoaFisicaHistEntity.getIdFonteDadosDataNascimento());
		pessoaFisicaEntity.setIdFonteDadosEstadoCivil(pessoaFisicaHistEntity.getIdFonteDadosEstadoCivil());
		pessoaFisicaEntity.setIdFonteDadosEstadoNascimento(pessoaFisicaHistEntity.getIdFonteDadosEstadoNascimento());
		pessoaFisicaEntity.setIdFonteDadosGenero(pessoaFisicaHistEntity.getIdFonteDadosGenero());
		pessoaFisicaEntity.setIdFonteDadosMae(pessoaFisicaHistEntity.getIdFonteDadosMae());
		pessoaFisicaEntity.setIdFonteDadosNacionalidade(pessoaFisicaHistEntity.getIdFonteDadosNacionalidade());
		pessoaFisicaEntity.setIdFonteDadosNomeCompleto(pessoaFisicaHistEntity.getIdFonteDadosNomeCompleto());
		pessoaFisicaEntity.setIdFonteDadosPai(pessoaFisicaHistEntity.getIdFonteDadosPai());
		pessoaFisicaEntity.setIdGenero(pessoaFisicaHistEntity.getIdGenero());
		pessoaFisicaEntity.setIdStelo(pessoaFisicaHistEntity.getIdStelo());
		pessoaFisicaEntity.setMotivoPessoaPoliticamenteExposta(pessoaFisicaHistEntity.getMotivoPessoaPoliticamenteExposta());
		pessoaFisicaEntity.setNmCompleto(pessoaFisicaHistEntity.getNmCompleto());
		pessoaFisicaEntity.setNmMae(pessoaFisicaHistEntity.getNmMae());
		pessoaFisicaEntity.setNmPai(pessoaFisicaHistEntity.getNmPai());
		pessoaFisicaEntity.setNomeFantasia(pessoaFisicaHistEntity.getNomeFantasia());
		pessoaFisicaEntity.setPessoaPoliticamenteExposta(pessoaFisicaHistEntity.getPessoaPoliticamenteExposta());
		pessoaFisicaEntity.setUsuarioAlteracao(pessoaFisicaHistEntity.getUsuarioAlteracao());
		pessoaFisicaEntity.setUsuarioInclusao(pessoaFisicaHistEntity.getUsuarioAlteracao());
		return pessoaFisicaEntity;
	}

}
