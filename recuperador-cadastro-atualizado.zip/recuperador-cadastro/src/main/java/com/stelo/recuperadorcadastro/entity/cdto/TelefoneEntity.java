
package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_FONE", schema = "USR_CADU")
public class TelefoneEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_FONE")
	private Long id;
	
	@Column(name = "NU_FONE")
	private String numeroTelefone;
	
	@Column(name = "DDD")
	private String ddd;
	
	@Column(name = "ID_FONTE_DADOS")
	private Integer idFonteDados;
	
	@Column(name = "ID_TP_FONE")
	private Integer idTipoTelefone;
	
	@Column(name = "STTUS")
	private Integer status;
	
	@Column(name = "ID_RLCTO")
	private Long idRelacionamento;
	
	@Column(name = "USUAR_INCL")
	private String usuarioInclusao;
	
	@Column(name = "USUAR_ALT")
	private String usuarioAlteracao;
	
	@Column(name = "DT_INCL")
	private Date dataInclusao;
	
	@Column(name = "DT_ALT")
	private Date dataAlteracao;
	
	@Column(name = "IC_FONE_PRINC")
	private Integer icFonePrincipal;
	
	@Column(name = "DT_ALT_FONE_PRINC")
	private Date dataAlteracaoFonePrinc;
	
	@Column(name = "IC_FONE_VALDDO")
	private Integer icFoneValido;
	
	@Column(name = "DT_FONE_VALDDO")
	private Date dataFoneValido;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public Integer getIdFonteDados() {
		return idFonteDados;
	}

	public void setIdFonteDados(Integer idFonteDados) {
		this.idFonteDados = idFonteDados;
	}

	public Integer getIdTipoTelefone() {
		return idTipoTelefone;
	}

	public void setIdTipoTelefone(Integer idTipoTelefone) {
		this.idTipoTelefone = idTipoTelefone;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getIdRelacionamento() {
		return idRelacionamento;
	}

	public void setIdRelacionamento(Long idRelacionamento) {
		this.idRelacionamento = idRelacionamento;
	}

	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Integer getIcFonePrincipal() {
		return icFonePrincipal;
	}

	public void setIcFonePrincipal(Integer icFonePrincipal) {
		this.icFonePrincipal = icFonePrincipal;
	}

	public Date getDataAlteracaoFonePrinc() {
		return dataAlteracaoFonePrinc;
	}

	public void setDataAlteracaoFonePrinc(Date dataAlteracaoFonePrinc) {
		this.dataAlteracaoFonePrinc = dataAlteracaoFonePrinc;
	}

	public Integer getIcFoneValido() {
		return icFoneValido;
	}

	public void setIcFoneValido(Integer icFoneValido) {
		this.icFoneValido = icFoneValido;
	}

	public Date getDataFoneValido() {
		return dataFoneValido;
	}

	public void setDataFoneValido(Date dataFoneValido) {
		this.dataFoneValido = dataFoneValido;
	}

	
	
}
