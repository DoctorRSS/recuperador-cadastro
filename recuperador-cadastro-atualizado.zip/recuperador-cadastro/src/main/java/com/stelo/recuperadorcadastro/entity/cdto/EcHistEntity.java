package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_EC_HIST", schema = "USR_CADU")
public class EcHistEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;
	
	@Column(name = "ID_STELO")
	private Long idStelo;

	/** The antec ativo. */
	@Column(name = "ANTEC_ATIVO")
	private Integer antecAtivo;

	/** The client secret. */
	@Column(name = "CLI_SECRET")
	private String clientSecret;

	/** The client secret anterior. */
	@Column(name = "CLI_SECRET_ANT")
	private String clientSecretAnterior;

	/** The dt alteracao. */
	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	/** The dt inclusao. */
	@Column(name = "DT_INCL", nullable = false)
	private Date dtInclusao;

	/** The id cli. */
	@Column(name = "ID_CLI")
	private String idCli;

	/** The id cli anterior. */
	@Column(name = "ID_CLI_ANT")
	private String idCliAnterior;

	/** The id merchant. */
	@Column(name = "ID_MERCHANT")
	private String idMerchant;

	/** The mcc. */
	private String mcc;

	/** The nm fatura cartao. */
	@Column(name = "NM_FAT_CATAO")
	private String nmFaturaCartao;

	/** The nu contrato. */
	@Column(name = "NU_CONTR")
	private Integer nuContrato;

	/** The parceiro distribuicao. */
	@Column(name = "ID_PCERO_DISTR")
	private Integer parceiroDistribuicao;

	/** The periodicidade saque. */
	@Column(name = "ID_PERDC_SAQUE")
	private Integer periodicidadeSaque;

	/** The status. */
	@Column(name = "STTUS", nullable = false)
	private Integer status;

	/** The tp ec. */
	@Column(name = "TP_EC", nullable = false)
	private Integer tpEc;

	/** The tp vendedor. */
	@Column(name = "TP_VDDOR")
	private String tpVendedor;

	/** The id indicacao antecipacao. */
	@Column(name = "ID_INDCD_ANTEC")
	private Integer idIndicacaoAntecipacao;

	/** The id situacao ec. */
	@Column(name = "ID_SIT_EC", nullable = false)
	private Integer idSituacaoEc;

	/** The quantidade funcionario. */
	@Column(name = "ID_QT_FUNC")
	private Integer quantidadeFuncionario;

	/** The id usuario alteracao. */
	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;

	/** The id usuario inclusao. */
	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;

	/** The saque automatico. */
	@Column(name = "SAQUE_AUTOM")
	private Integer saqueAutomatico;

	/** The gerente responsavel. */
	@Column(name = "GER_RESP")
	private String gerenteResponsavel;

	/** The conf autom. */
	@Column(name = "CONF_AUTOM")
	private Integer confAutom;

	/** The id categ. */
	@Column(name = "ID_CATEG")
	private String idCateg;

	/** The id cnae. */
	@Column(name = "ID_CNAE")
	private String idCnae;

	/** The id sub categ. */
	@Column(name = "ID_SUB_CATEG")
	private String idSubCateg;

	/** The id forma costituicao. */
	@Column(name = "ID_FORMA_CNSTT", nullable = false)
	private Integer idFormaCostituicao;

	/** The id tpo intgc. */
	@Column(name = "ID_TP_INTGC")
	private Integer idTpoIntgc;

	/** The id porte ec. */
	@Column(name = "ID_PORTE_EC")
	private Integer idPorteEc;

	/** The id platf. */
	@Column(name = "ID_PLATF")
	private Integer idPlatf;

	/** The prmss canc. */
	@Column(name = "PRMSS_CANC")
	private boolean prmssCanc;

	/** The flag envio email trans *. */
	@Column(name = "FLG_ENVIO_EMAIL_TRANS", nullable = false)
	private boolean flgEnvioEmailTrans;

	/** The perc markup platf. */
	@Column(name = "PC_MARKUP_PLATF")
	private Double percMarkupPlatf;

	/** The id parceiro. */
	@Column(name = "ID_PCERO")
	private Integer idParceiro;

	/** The perc markup parceiro. */
	@Column(name = "PC_MARKUP_PCERO")
	private Double percMarkupParceiro;

	/** The id banco. */
	@Column(name = "ID_BCO")
	private Integer idBanco;

	/** The perc markup banco. */
	@Column(name = "PC_MARKUP_BCO")
	private Double percMarkupBanco;

	@Column(name = "ID_MTRIZ")
	private Integer idMatriz;


	/** The tipo regra monitoracao cancelamento. */
	@Column(name = "IC_TPO_REGRA_MONIT_CANC")
	private String tipoRegraMonitoracaoCancelamento;

	/** The data alteracao regra monitoracao cancelamento. */
	@Column(name = "DT_ALT_TPO_REGRA_MONIT_CANC")
	private Date dataAlteracaoRegraMonitoracaoCancelamento;

	/** The flg envio email comp. */
	@Column(name = "FLG_ENVIO_EMAIL_COMPR", nullable = false)
	private boolean flgEnvioEmailComp;

	 @Column(name = "FLG_CAD_MDULO_TERM")
	 private Integer flagCadastroModuloTerminal ;

	@Column(name = "CD_EC_MDULO_TERM")
	private String codigoEcModuloTerminal;

	/** The flg gerente responsavel. */
	@Column(name = "FLG_GER_RESP")
	private Integer flgGerenteResponsavel;
	
	@Column(name = "SITE")
	private String site;
	
	@Column(name = "URL_STTUS")
	private String urlStatus;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public Integer getAntecAtivo() {
		return antecAtivo;
	}

	public void setAntecAtivo(Integer antecAtivo) {
		this.antecAtivo = antecAtivo;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getClientSecretAnterior() {
		return clientSecretAnterior;
	}

	public void setClientSecretAnterior(String clientSecretAnterior) {
		this.clientSecretAnterior = clientSecretAnterior;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getIdCli() {
		return idCli;
	}

	public void setIdCli(String idCli) {
		this.idCli = idCli;
	}

	public String getIdCliAnterior() {
		return idCliAnterior;
	}

	public void setIdCliAnterior(String idCliAnterior) {
		this.idCliAnterior = idCliAnterior;
	}

	public String getIdMerchant() {
		return idMerchant;
	}

	public void setIdMerchant(String idMerchant) {
		this.idMerchant = idMerchant;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}

	public String getNmFaturaCartao() {
		return nmFaturaCartao;
	}

	public void setNmFaturaCartao(String nmFaturaCartao) {
		this.nmFaturaCartao = nmFaturaCartao;
	}

	public Integer getNuContrato() {
		return nuContrato;
	}

	public void setNuContrato(Integer nuContrato) {
		this.nuContrato = nuContrato;
	}

	public Integer getParceiroDistribuicao() {
		return parceiroDistribuicao;
	}

	public void setParceiroDistribuicao(Integer parceiroDistribuicao) {
		this.parceiroDistribuicao = parceiroDistribuicao;
	}

	public Integer getPeriodicidadeSaque() {
		return periodicidadeSaque;
	}

	public void setPeriodicidadeSaque(Integer periodicidadeSaque) {
		this.periodicidadeSaque = periodicidadeSaque;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getTpEc() {
		return tpEc;
	}

	public void setTpEc(Integer tpEc) {
		this.tpEc = tpEc;
	}

	public String getTpVendedor() {
		return tpVendedor;
	}

	public void setTpVendedor(String tpVendedor) {
		this.tpVendedor = tpVendedor;
	}

	public Integer getIdIndicacaoAntecipacao() {
		return idIndicacaoAntecipacao;
	}

	public void setIdIndicacaoAntecipacao(Integer idIndicacaoAntecipacao) {
		this.idIndicacaoAntecipacao = idIndicacaoAntecipacao;
	}

	public Integer getIdSituacaoEc() {
		return idSituacaoEc;
	}

	public void setIdSituacaoEc(Integer idSituacaoEc) {
		this.idSituacaoEc = idSituacaoEc;
	}

	public Integer getQuantidadeFuncionario() {
		return quantidadeFuncionario;
	}

	public void setQuantidadeFuncionario(Integer quantidadeFuncionario) {
		this.quantidadeFuncionario = quantidadeFuncionario;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public Integer getSaqueAutomatico() {
		return saqueAutomatico;
	}

	public void setSaqueAutomatico(Integer saqueAutomatico) {
		this.saqueAutomatico = saqueAutomatico;
	}

	public String getGerenteResponsavel() {
		return gerenteResponsavel;
	}

	public void setGerenteResponsavel(String gerenteResponsavel) {
		this.gerenteResponsavel = gerenteResponsavel;
	}

	public Integer getConfAutom() {
		return confAutom;
	}

	public void setConfAutom(Integer confAutom) {
		this.confAutom = confAutom;
	}

	public String getIdCateg() {
		return idCateg;
	}

	public void setIdCateg(String idCateg) {
		this.idCateg = idCateg;
	}

	public String getIdCnae() {
		return idCnae;
	}

	public void setIdCnae(String idCnae) {
		this.idCnae = idCnae;
	}

	public String getIdSubCateg() {
		return idSubCateg;
	}

	public void setIdSubCateg(String idSubCateg) {
		this.idSubCateg = idSubCateg;
	}

	public Integer getIdFormaCostituicao() {
		return idFormaCostituicao;
	}

	public void setIdFormaCostituicao(Integer idFormaCostituicao) {
		this.idFormaCostituicao = idFormaCostituicao;
	}

	public Integer getIdTpoIntgc() {
		return idTpoIntgc;
	}

	public void setIdTpoIntgc(Integer idTpoIntgc) {
		this.idTpoIntgc = idTpoIntgc;
	}

	public Integer getIdPorteEc() {
		return idPorteEc;
	}

	public void setIdPorteEc(Integer idPorteEc) {
		this.idPorteEc = idPorteEc;
	}

	public Integer getIdPlatf() {
		return idPlatf;
	}

	public void setIdPlatf(Integer idPlatf) {
		this.idPlatf = idPlatf;
	}

	public boolean isPrmssCanc() {
		return prmssCanc;
	}

	public void setPrmssCanc(boolean prmssCanc) {
		this.prmssCanc = prmssCanc;
	}

	public boolean isFlgEnvioEmailTrans() {
		return flgEnvioEmailTrans;
	}

	public void setFlgEnvioEmailTrans(boolean flgEnvioEmailTrans) {
		this.flgEnvioEmailTrans = flgEnvioEmailTrans;
	}

	public Double getPercMarkupPlatf() {
		return percMarkupPlatf;
	}

	public void setPercMarkupPlatf(Double percMarkupPlatf) {
		this.percMarkupPlatf = percMarkupPlatf;
	}

	public Integer getIdParceiro() {
		return idParceiro;
	}

	public void setIdParceiro(Integer idParceiro) {
		this.idParceiro = idParceiro;
	}

	public Double getPercMarkupParceiro() {
		return percMarkupParceiro;
	}

	public void setPercMarkupParceiro(Double percMarkupParceiro) {
		this.percMarkupParceiro = percMarkupParceiro;
	}

	public Integer getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(Integer idBanco) {
		this.idBanco = idBanco;
	}

	public Double getPercMarkupBanco() {
		return percMarkupBanco;
	}

	public void setPercMarkupBanco(Double percMarkupBanco) {
		this.percMarkupBanco = percMarkupBanco;
	}

	public Integer getIdMatriz() {
		return idMatriz;
	}

	public void setIdMatriz(Integer idMatriz) {
		this.idMatriz = idMatriz;
	}

	public String getTipoRegraMonitoracaoCancelamento() {
		return tipoRegraMonitoracaoCancelamento;
	}

	public void setTipoRegraMonitoracaoCancelamento(String tipoRegraMonitoracaoCancelamento) {
		this.tipoRegraMonitoracaoCancelamento = tipoRegraMonitoracaoCancelamento;
	}

	public Date getDataAlteracaoRegraMonitoracaoCancelamento() {
		return dataAlteracaoRegraMonitoracaoCancelamento;
	}

	public void setDataAlteracaoRegraMonitoracaoCancelamento(Date dataAlteracaoRegraMonitoracaoCancelamento) {
		this.dataAlteracaoRegraMonitoracaoCancelamento = dataAlteracaoRegraMonitoracaoCancelamento;
	}

	public boolean isFlgEnvioEmailComp() {
		return flgEnvioEmailComp;
	}

	public void setFlgEnvioEmailComp(boolean flgEnvioEmailComp) {
		this.flgEnvioEmailComp = flgEnvioEmailComp;
	}

	public Integer getFlagCadastroModuloTerminal() {
		return flagCadastroModuloTerminal;
	}

	public void setFlagCadastroModuloTerminal(Integer flagCadastroModuloTerminal) {
		this.flagCadastroModuloTerminal = flagCadastroModuloTerminal;
	}

	public String getCodigoEcModuloTerminal() {
		return codigoEcModuloTerminal;
	}

	public void setCodigoEcModuloTerminal(String codigoEcModuloTerminal) {
		this.codigoEcModuloTerminal = codigoEcModuloTerminal;
	}

	public Integer getFlgGerenteResponsavel() {
		return flgGerenteResponsavel;
	}

	public void setFlgGerenteResponsavel(Integer flgGerenteResponsavel) {
		this.flgGerenteResponsavel = flgGerenteResponsavel;
	}

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getUrlStatus() {
		return urlStatus;
	}

	public void setUrlStatus(String urlStatus) {
		this.urlStatus = urlStatus;
	}
}
