package com.stelo.recuperadorcadastro.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoHistEntity;
import com.stelo.recuperadorcadastro.service.MaquinaCartaoService;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Controller
@RequestMapping("maquinaCartao")
public class MaquinaCartaoEndpoint {

	@Autowired
	private MaquinaCartaoService maquinaCartaoService;
	
	@RequestMapping("/alterar")
	public ModelAndView novo(Long idStelo) {
		ModelAndView mv = new ModelAndView("maquinaCartao-historico/listar");
		mv.addObject("idStelo", idStelo);
		return mv;
	}
	
	@GetMapping
	public ModelAndView buscarHistorico(Long idStelo) {
		ModelAndView mv = new ModelAndView("maquinaCartao-historico/listar");
		mv.addObject("idStelo", idStelo);
		List<MaquinaCartaoHistEntity> listaMaquinaCartao = new ArrayList<MaquinaCartaoHistEntity>();
		try {
			listaMaquinaCartao = maquinaCartaoService.buscar(idStelo);
		} catch(IdSteloObrigatorioException e) {
			mv.addObject("mensagemError", e.getMessage());
			return mv;
		}
		
		mv.addObject("maquinaCartaosHist",listaMaquinaCartao);
		
		return mv;
		
	}
	
	@PutMapping
	public ResponseEntity<?> salvar(MaquinaCartaoHistEntity maquinaCartaoHistEntity){
		try {
			maquinaCartaoService.salvar(maquinaCartaoHistEntity);
		} catch (ObjetoNuloException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok("Sucesso");
	}
}
