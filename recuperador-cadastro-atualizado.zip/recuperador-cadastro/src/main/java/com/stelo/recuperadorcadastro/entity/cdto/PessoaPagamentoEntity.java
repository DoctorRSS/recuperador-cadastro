package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_PSSOA_PGTO")
public class PessoaPagamentoEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_STELO")
	private Long idStelo;

	@Column(name = "ATIVO_CAD_PGTO")
	private Integer ativoCadastroPagto;

	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Column(name = "DT_INCL")
	private Date dtInclusao;

	@Column(name = "ID_PGTO_CAD")
	private String idPgtoCadastro;

	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;

	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;

	@Column(name = "STTUS")
	private Integer status;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public Integer getAtivoCadastroPagto() {
		return ativoCadastroPagto;
	}

	public void setAtivoCadastroPagto(Integer ativoCadastroPagto) {
		this.ativoCadastroPagto = ativoCadastroPagto;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getIdPgtoCadastro() {
		return idPgtoCadastro;
	}

	public void setIdPgtoCadastro(String idPgtoCadastro) {
		this.idPgtoCadastro = idPgtoCadastro;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
}
