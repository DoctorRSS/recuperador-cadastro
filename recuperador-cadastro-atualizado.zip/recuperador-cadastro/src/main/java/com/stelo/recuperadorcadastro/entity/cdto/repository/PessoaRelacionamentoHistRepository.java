package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoHistEntity;

@Repository
public interface PessoaRelacionamentoHistRepository extends JpaRepository<PessoaRelacionamentoHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_PSSOA_RLCTO_HIST where id_stelo = :idStelo ", nativeQuery=true)
	List<PessoaRelacionamentoHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
