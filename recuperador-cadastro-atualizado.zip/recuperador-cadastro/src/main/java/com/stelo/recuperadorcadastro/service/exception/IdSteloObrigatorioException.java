package com.stelo.recuperadorcadastro.service.exception;

public class IdSteloObrigatorioException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public IdSteloObrigatorioException(String message) {
		super(message);
	}

}
