package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRelacionamentoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRelacionamentoRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class PessoaRelacionamentoService {

	@Autowired
	private PessoaRelacionamentoHistRepository pessoaRelacionamentoHistRepository;
	
	@Autowired
	private PessoaRelacionamentoRepository pessoaRelacionamentoRepository;
	
	public PessoaRelacionamentoService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<PessoaRelacionamentoHistEntity> buscar(Long idStelo){
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaRelacionamentoHistEntity> listaRelacionamentoHist =
				pessoaRelacionamentoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaRelacionamentoHist;
	}
	
	@PutMapping
	public void salvar(PessoaRelacionamentoHistEntity pessoaRelacionamentoHistEntity) throws ObjetoNuloException {
		PessoaRelacionamentoEntity pessoaRelacionamentoEntity;
		try {
			pessoaRelacionamentoEntity = construirPesoaRelacionamento(pessoaRelacionamentoHistEntity);
			pessoaRelacionamentoRepository.save(pessoaRelacionamentoEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private PessoaRelacionamentoEntity construirPesoaRelacionamento(
			PessoaRelacionamentoHistEntity pessoaRelacionamentoHistEntity) throws ObjetoNuloException {
		PessoaRelacionamentoEntity pessoaRelacionamentoEntity = new PessoaRelacionamentoEntity();
		
		if(pessoaRelacionamentoHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de pessoa relacionamento para Alteração!");
		
		pessoaRelacionamentoEntity.setEc(pessoaRelacionamentoHistEntity.getEc());
		pessoaRelacionamentoEntity.setId(pessoaRelacionamentoHistEntity.getId());
		pessoaRelacionamentoEntity.setIdStelo(pessoaRelacionamentoHistEntity.getIdStelo());
		pessoaRelacionamentoEntity.setIdRlctoPagamento(pessoaRelacionamentoHistEntity.getIdRlctoPagamento());
		pessoaRelacionamentoEntity.setIdTipoRelacionamento(pessoaRelacionamentoHistEntity.getIdTipoRelacionamento());
		pessoaRelacionamentoEntity.setStatus(pessoaRelacionamentoHistEntity.getStatus());
		
		return pessoaRelacionamentoEntity;
	}

}
