package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaJuridicaHistEntity;

@Repository
public interface PessoaJuridicaHistRepository extends JpaRepository<PessoaJuridicaHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_PSSOA_JURID_HIST where id_stelo = :idStelo ", nativeQuery=true)
	List<PessoaJuridicaHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
