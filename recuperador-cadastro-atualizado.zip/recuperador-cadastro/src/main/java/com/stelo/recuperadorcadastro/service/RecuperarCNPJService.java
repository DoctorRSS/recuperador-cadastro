package com.stelo.recuperadorcadastro.service;

import org.springframework.stereotype.Service;

@Service
public class RecuperarCNPJService {

}
