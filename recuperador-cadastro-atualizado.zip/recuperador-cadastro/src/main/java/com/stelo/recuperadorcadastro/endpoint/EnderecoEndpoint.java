package com.stelo.recuperadorcadastro.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.stelo.recuperadorcadastro.entity.cdto.EnderecoHistEntity;
import com.stelo.recuperadorcadastro.service.EnderecoService;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Controller
@RequestMapping("endereco")
public class EnderecoEndpoint {

	@Autowired
	private EnderecoService enderecoService;
	
	@RequestMapping("/alterar")
	public ModelAndView novo(Long idStelo) {
		ModelAndView mv = new ModelAndView("endereco-historico/listar");
		mv.addObject("idStelo", idStelo);
		return mv;
	}
	
	@GetMapping
	public ModelAndView buscarHistorico(Long idStelo) {
		ModelAndView mv = new ModelAndView("endereco-historico/listar");
		mv.addObject("idStelo", idStelo);
		List<EnderecoHistEntity> listaEndereco = new ArrayList<EnderecoHistEntity>();
		try {
			listaEndereco = enderecoService.buscar(idStelo);
		} catch(IdSteloObrigatorioException e) {
			mv.addObject("mensagemError", e.getMessage());
			return mv;
		}
		
		mv.addObject("enderecosHist",listaEndereco);
		
		return mv;
		
	}
	
	@PutMapping
	public ResponseEntity<?> salvar(EnderecoHistEntity enderecoHistEntity){
		try {
			enderecoService.salvar(enderecoHistEntity);
		} catch (ObjetoNuloException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok("Sucesso");
	}
}
