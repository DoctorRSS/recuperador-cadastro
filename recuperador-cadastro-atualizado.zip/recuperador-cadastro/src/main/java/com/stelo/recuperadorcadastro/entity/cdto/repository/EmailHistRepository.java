package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.EmailHistEntity;

@Repository
public interface EmailHistRepository extends JpaRepository<EmailHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_EMAIL_HIST where id_rlcto in "
			+ "(select id_rlcto from USR_CADU.TB_PSSOA_RLCTO_hist where id_stelo = :idStelo)"
			, nativeQuery=true)
	List<EmailHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
