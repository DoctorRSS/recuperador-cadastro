package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaPagamentoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaPagamentoRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class ContaPagamentoService {

	@Autowired
	private ContaPagamentoHistRepository contaPagamentoHistRepository;
	
	@Autowired
	private ContaPagamentoRepository contaPagamentoRepository;
	
	public ContaPagamentoService() {
		// TODO Auto-generated constructor stub
	}

	@GetMapping
	public List<ContaPagamentoHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<ContaPagamentoHistEntity> listaContaPagamentoHist =
				contaPagamentoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaContaPagamentoHist;
	}
	
	@PutMapping
	public void salvar(ContaPagamentoHistEntity contaPagamentoHistEntity) throws ObjetoNuloException{
		ContaPagamentoEntity contaPagamentoEntity;
		try {
			contaPagamentoEntity = construirContaPagamento(contaPagamentoHistEntity);
			contaPagamentoRepository.save(contaPagamentoEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private ContaPagamentoEntity construirContaPagamento(ContaPagamentoHistEntity contaPagamentoHistEntity) throws ObjetoNuloException{
		ContaPagamentoEntity contaPagamentoEntity = new ContaPagamentoEntity();
		
		if(contaPagamentoHistEntity==null)
			throw new ObjetoNuloException("Não foi informado o histórico de conta pagamento para Alteração!");
		
		contaPagamentoEntity.setDiaMesCobrancaTarifa(contaPagamentoHistEntity.getDiaMesCobrancaTarifa());
		contaPagamentoEntity.setDtAlteracao(contaPagamentoHistEntity.getDtAlteracao());
		contaPagamentoEntity.setDtCadastro(contaPagamentoHistEntity.getDtCadastro());
		contaPagamentoEntity.setDtInclusao(contaPagamentoHistEntity.getDtInclusao());
		contaPagamentoEntity.setDtVecimentoIsencaoTarifa(contaPagamentoHistEntity.getDtVecimentoIsencaoTarifa());
		contaPagamentoEntity.setIdConta(contaPagamentoHistEntity.getIdConta());
		contaPagamentoEntity.setIdMotivoBloqueioContaPgtoDm(contaPagamentoHistEntity.getIdMotivoBloqueioContaPgtoDm());
		contaPagamentoEntity.setIdPgtoConta(contaPagamentoHistEntity.getIdPgtoConta());
		contaPagamentoEntity.setIdUsuarioAlteracao(contaPagamentoHistEntity.getIdUsuarioAlteracao());
		contaPagamentoEntity.setIdUsuarioInclusao(contaPagamentoHistEntity.getIdUsuarioInclusao());
		contaPagamentoEntity.setNuGrupoContabil(contaPagamentoHistEntity.getNuGrupoContabil());
		contaPagamentoEntity.setPeriodoCobrancaTarifa(contaPagamentoHistEntity.getPeriodoCobrancaTarifa());
		contaPagamentoEntity.setStatus(contaPagamentoHistEntity.getStatus());
		contaPagamentoEntity.setTarifaAniversario(contaPagamentoHistEntity.getTarifaAniversario());
		contaPagamentoEntity.setTarifaCadastro(contaPagamentoHistEntity.getTarifaCadastro());
		contaPagamentoEntity.setTarifaContaPgto(contaPagamentoHistEntity.getTarifaContaPgto());
		
		return contaPagamentoEntity;
	}
}
