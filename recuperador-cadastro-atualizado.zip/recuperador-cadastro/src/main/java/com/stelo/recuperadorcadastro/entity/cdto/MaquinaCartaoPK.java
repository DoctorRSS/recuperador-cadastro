package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;

import javax.persistence.Column;

public class MaquinaCartaoPK implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "NU_TERM", nullable = false)
	private Long nuTerm;
	
	@Column(name = "NU_SERIE", nullable = false)
	private String nuSerie;
	
	public MaquinaCartaoPK(){
	
	}

	public MaquinaCartaoPK(Long nuTerm, String nuSerie) {
		this.nuTerm = nuTerm;
		this.nuSerie = nuSerie;
	}

	public Long getNuTerm() {
		return nuTerm;
	}

	public void setNuTerm(Long nuTerm) {
		this.nuTerm = nuTerm;
	}

	public String getNuSerie() {
		return nuSerie;
	}

	public void setNuSerie(String nuSerie) {
		this.nuSerie = nuSerie;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nuSerie == null) ? 0 : nuSerie.hashCode());
		result = prime * result + ((nuTerm == null) ? 0 : nuTerm.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MaquinaCartaoPK other = (MaquinaCartaoPK) obj;
		if (nuSerie == null) {
			if (other.nuSerie != null)
				return false;
		} else if (!nuSerie.equals(other.nuSerie))
			return false;
		if (nuTerm == null) {
			if (other.nuTerm != null)
				return false;
		} else if (!nuTerm.equals(other.nuTerm))
			return false;
		return true;
	}


}
