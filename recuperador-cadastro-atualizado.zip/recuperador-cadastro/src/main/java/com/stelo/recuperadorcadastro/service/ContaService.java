package com.stelo.recuperadorcadastro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.ContaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class ContaService {
	
	@Autowired
	private ContaHistRepository contaHistRepository;
	
	@Autowired
	private ContaRepository contaRepository;

	public ContaService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<ContaHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<ContaHistEntity> listaContaHist =
				contaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaContaHist;
	}
	
	@PutMapping
	public void salvar(List<ContaHistEntity> contaHistEntity) throws ObjetoNuloException {
		List<ContaEntity> contasEntity;
		try {
			contasEntity = construirContas(contaHistEntity);
			contaRepository.save(contasEntity);
			//contaRepository.saveAll(contasEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	

	private List<ContaEntity> construirContas(List<ContaHistEntity> contasHistEntity) throws ObjetoNuloException {
		List<ContaEntity> listaEntity = new ArrayList<ContaEntity>();
		
		if(contasHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de contas para Alteração!");
		
		for(ContaHistEntity contaHist : contasHistEntity) {
			ContaEntity conta = new ContaEntity();
			conta.setAgencia(contaHist.getAgencia());
			conta.setBloqueado(contaHist.getBloqueado());
			conta.setConta(contaHist.getConta());
			conta.setDigitoAgencia(contaHist.getDigitoAgencia());
			conta.setDigitoConta(contaHist.getDigitoConta());
			conta.setDtAbert(contaHist.getDtAbert());
			conta.setDtAlteracao(contaHist.getDtAlteracao());
			conta.setDtInclusao(contaHist.getDtInclusao());
			conta.setId(contaHist.getId());
			conta.setIdBanco(contaHist.getIdBanco());
			conta.setIdFuncaoCta(contaHist.getIdFuncaoCta());
			conta.setIdRelacionamento(contaHist.getIdRelacionamento());
			conta.setIdTpCta(contaHist.getIdTpCta());
			conta.setIdUsuarioAlteracao(contaHist.getIdUsuarioAlteracao());
			conta.setIdUsuarioInclusao(contaHist.getIdUsuarioInclusao());
			conta.setStatus(contaHist.getStatus());
			listaEntity.add(conta);
		}
		
		return listaEntity;
	}

}
