package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoHistEntity;

@Repository
public interface MaquinaCartaoHistRepository extends JpaRepository<MaquinaCartaoHistEntity, Long> {
	
	@Query(value = "select * from USR_CADU.TB_MAQNA_CATAO_HIST where nu_term in ( "
			+ "select nu_term from USR_CADU.TB_TERM_HIST where id_stelo = :idStelo and id_tecno = '8' ) "
			, nativeQuery=true)
	List<MaquinaCartaoHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);

}
