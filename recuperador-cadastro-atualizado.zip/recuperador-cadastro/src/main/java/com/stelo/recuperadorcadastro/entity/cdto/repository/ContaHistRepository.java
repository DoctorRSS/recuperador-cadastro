package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.ContaHistEntity;

@Repository
public interface ContaHistRepository extends JpaRepository<ContaHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_CTA_HIST where id_rlcto in "
			+ "( select id_rlcto from USR_CADU.TB_PSSOA_RLCTO_HIST where id_stelo = :idStelo ) "
			, nativeQuery=true)
	List<ContaHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
