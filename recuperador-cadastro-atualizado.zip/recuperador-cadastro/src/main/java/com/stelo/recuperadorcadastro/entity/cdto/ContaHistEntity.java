package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_CTA_HIST", schema = "USR_CADU")
public class ContaHistEntity implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;
	
	@Column(name = "ID_CTA")
	private Long id;

	@Column(name = "ID_BCO")
	private Long idBanco;

	@Column(name = "NU_AG")
	private String agencia;

	@Column(name = "NU_DIG_AG")
	private String digitoAgencia;

	@Column(name = "NU_CTA")
	private String conta;

	@Column(name = "NU_DIG_CTA")
	private String digitoConta;

	@Column(name = "ID_RLCTO")
	private Long idRelacionamento;
	
	@Column(name = "DT_ABERT")
	private Date dtAbert;
	
	@Column(name = "STTUS")
	private Integer status;
	
	@Column(name = "ID_TP_CTA")
	private Integer idTpCta;
	
	@Column(name = "ID_FNCAO_CTA")
	private Integer idFuncaoCta;
	
	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Column(name = "DT_INCL")
	private Date dtInclusao;
	
	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;
	
	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;
	
	@Column(name = "BLOQUEADO")
	private Integer bloqueado;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(Long idBanco) {
		this.idBanco = idBanco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getDigitoAgencia() {
		return digitoAgencia;
	}

	public void setDigitoAgencia(String digitoAgencia) {
		this.digitoAgencia = digitoAgencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getDigitoConta() {
		return digitoConta;
	}

	public void setDigitoConta(String digitoConta) {
		this.digitoConta = digitoConta;
	}

	public Long getIdRelacionamento() {
		return idRelacionamento;
	}

	public void setIdRelacionamento(Long idRelacionamento) {
		this.idRelacionamento = idRelacionamento;
	}

	public Date getDtAbert() {
		return dtAbert;
	}

	public void setDtAbert(Date dtAbert) {
		this.dtAbert = dtAbert;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIdTpCta() {
		return idTpCta;
	}

	public void setIdTpCta(Integer idTpCta) {
		this.idTpCta = idTpCta;
	}

	public Integer getIdFuncaoCta() {
		return idFuncaoCta;
	}

	public void setIdFuncaoCta(Integer idFuncaoCta) {
		this.idFuncaoCta = idFuncaoCta;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public Integer getBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(Integer bloqueado) {
		this.bloqueado = bloqueado;
	}

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

}
