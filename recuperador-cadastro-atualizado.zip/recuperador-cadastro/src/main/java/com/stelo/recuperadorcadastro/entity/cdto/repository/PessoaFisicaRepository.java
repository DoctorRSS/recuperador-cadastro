package com.stelo.recuperadorcadastro.entity.cdto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaEntity;

@Repository
public interface PessoaFisicaRepository extends JpaRepository<PessoaFisicaEntity, Long> {

}
