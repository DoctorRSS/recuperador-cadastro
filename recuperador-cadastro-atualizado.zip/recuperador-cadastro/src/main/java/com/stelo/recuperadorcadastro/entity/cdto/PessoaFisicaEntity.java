package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_PSSOA_FIS", schema = "USR_CADU")
public class PessoaFisicaEntity implements Serializable {


	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_STELO")
	private Long idStelo;

	/** The cidade nascimento. */
	@Column(name = "CIDDE_NASC")
	private String cidadeNascimento;
	

	@Column(name = "CPF")
	private String cpf;

	/** The ds nacionalidade. */
	@Column(name = "DS_NAC")
	private String dsNacionalidade;

	/** The dt nascimento. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DT_NASC")
	private Date dtNascimento;

	/** The estado nascimento. */
	@Column(name = "EST_NASC")
	private String estadoNascimento;

	/** The filhos. */
	@Column(name = "FILHOS")
	private Integer filhos;

	/** The nm completo. */
	@Column(name = "NM_COPLT")
	private String nmCompleto;

	/** The nm mae. */
	@Column(name = "NM_MAE")
	private String nmMae;

	/** The nm pai. */
	@Column(name = "NM_PAI")
	private String nmPai;

	/** The id fonte dados cpf dm. */
	@Column(name = "ID_FONTE_DADOS_CPF")
	private Integer idFonteDadosCpfDm;

	/** The id estado civil dm. */
	@Column(name = "ID_EST_CVIL")
	private Integer idEstadoCivilDm;

	/** The motivo pessoa politicamente exposta. */
	@Column(name = "MOTVO_PSSOA_POLTC_EXP")
	private String motivoPessoaPoliticamenteExposta;

	/** The pessoa politicamente exposta. */
	@Column(name = "PSSOA_POLTC_EXP")
	private Integer pessoaPoliticamenteExposta;

	/** The id genero. */
	@Column(name = "ID_GNRO")
	private Integer idGenero;

	/** The usuario alteracao. */
	@Column(name = "USUAR_ALT")
	private String usuarioAlteracao;

	/** The usuario inclusao. */
	@Column(name = "USUAR_INCL")
	private String usuarioInclusao;

	/** The id fonte dados nome completo. */
	@Column(name = "ID_FONTE_DADOS_NM_COPLT")
	private Integer idFonteDadosNomeCompleto;

	/** The id fonte dados genero. */
	@Column(name = "ID_FONTE_DADOS_GNRO")
	private Integer idFonteDadosGenero;

	/** The id fonte dados pai. */
	@Column(name = "ID_FONTE_DADOS_NM_PAI")
	private Integer idFonteDadosPai;

	/** The id fonte dados mae. */
	@Column(name = "ID_FONTE_DADOS_NM_MAE")
	private Integer idFonteDadosMae;

	/** The id fonte dados cidade nascimento. */
	@Column(name = "ID_FONTE_DADOS_CIDDE_NASC")
	private Integer idFonteDadosCidadeNascimento;

	/** The id fonte dados nacionalidade. */
	@Column(name = "ID_FONTE_DADOS_NAC")
	private Integer idFonteDadosNacionalidade;

	/** The id fonte dados estado nascimento. */
	@Column(name = "ID_FONTE_DADOS_EST_NASC")
	private Integer idFonteDadosEstadoNascimento;

	/** The id fonte dados estado civil. */
	@Column(name = "ID_FONTE_DADOS_EST_CVIL")
	private Integer idFonteDadosEstadoCivil;

	/** The id fonte dados data nascimento. */
	@Column(name = "ID_FONTE_DADOS_DT_NASC")
	private Integer idFonteDadosDataNascimento;

	/** The dt alteracao. */
	// @Temporal(TemporalType.DATE)
	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	/** The dt inclusao. */
	// @Temporal(TemporalType.DATE)
	@Column(name = "DT_INCL")
	private Date dtInclusao;

	/** The nome fantasia. */
	@Column(name = "NM_FANTS")
	private String nomeFantasia;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getDsNacionalidade() {
		return dsNacionalidade;
	}

	public void setDsNacionalidade(String dsNacionalidade) {
		this.dsNacionalidade = dsNacionalidade;
	}

	public Date getDtNascimento() {
		return dtNascimento;
	}

	public void setDtNascimento(Date dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimento(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Integer getFilhos() {
		return filhos;
	}

	public void setFilhos(Integer filhos) {
		this.filhos = filhos;
	}

	public String getNmCompleto() {
		return nmCompleto;
	}

	public void setNmCompleto(String nmCompleto) {
		this.nmCompleto = nmCompleto;
	}

	public String getNmMae() {
		return nmMae;
	}

	public void setNmMae(String nmMae) {
		this.nmMae = nmMae;
	}

	public String getNmPai() {
		return nmPai;
	}

	public void setNmPai(String nmPai) {
		this.nmPai = nmPai;
	}

	public Integer getIdFonteDadosCpfDm() {
		return idFonteDadosCpfDm;
	}

	public void setIdFonteDadosCpfDm(Integer idFonteDadosCpfDm) {
		this.idFonteDadosCpfDm = idFonteDadosCpfDm;
	}

	public Integer getIdEstadoCivilDm() {
		return idEstadoCivilDm;
	}

	public void setIdEstadoCivilDm(Integer idEstadoCivilDm) {
		this.idEstadoCivilDm = idEstadoCivilDm;
	}

	public String getMotivoPessoaPoliticamenteExposta() {
		return motivoPessoaPoliticamenteExposta;
	}

	public void setMotivoPessoaPoliticamenteExposta(String motivoPessoaPoliticamenteExposta) {
		this.motivoPessoaPoliticamenteExposta = motivoPessoaPoliticamenteExposta;
	}

	public Integer getPessoaPoliticamenteExposta() {
		return pessoaPoliticamenteExposta;
	}

	public void setPessoaPoliticamenteExposta(Integer pessoaPoliticamenteExposta) {
		this.pessoaPoliticamenteExposta = pessoaPoliticamenteExposta;
	}

	public Integer getIdGenero() {
		return idGenero;
	}

	public void setIdGenero(Integer idGenero) {
		this.idGenero = idGenero;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public Integer getIdFonteDadosNomeCompleto() {
		return idFonteDadosNomeCompleto;
	}

	public void setIdFonteDadosNomeCompleto(Integer idFonteDadosNomeCompleto) {
		this.idFonteDadosNomeCompleto = idFonteDadosNomeCompleto;
	}

	public Integer getIdFonteDadosGenero() {
		return idFonteDadosGenero;
	}

	public void setIdFonteDadosGenero(Integer idFonteDadosGenero) {
		this.idFonteDadosGenero = idFonteDadosGenero;
	}

	public Integer getIdFonteDadosPai() {
		return idFonteDadosPai;
	}

	public void setIdFonteDadosPai(Integer idFonteDadosPai) {
		this.idFonteDadosPai = idFonteDadosPai;
	}

	public Integer getIdFonteDadosMae() {
		return idFonteDadosMae;
	}

	public void setIdFonteDadosMae(Integer idFonteDadosMae) {
		this.idFonteDadosMae = idFonteDadosMae;
	}

	public Integer getIdFonteDadosCidadeNascimento() {
		return idFonteDadosCidadeNascimento;
	}

	public void setIdFonteDadosCidadeNascimento(Integer idFonteDadosCidadeNascimento) {
		this.idFonteDadosCidadeNascimento = idFonteDadosCidadeNascimento;
	}

	public Integer getIdFonteDadosNacionalidade() {
		return idFonteDadosNacionalidade;
	}

	public void setIdFonteDadosNacionalidade(Integer idFonteDadosNacionalidade) {
		this.idFonteDadosNacionalidade = idFonteDadosNacionalidade;
	}

	public Integer getIdFonteDadosEstadoNascimento() {
		return idFonteDadosEstadoNascimento;
	}

	public void setIdFonteDadosEstadoNascimento(Integer idFonteDadosEstadoNascimento) {
		this.idFonteDadosEstadoNascimento = idFonteDadosEstadoNascimento;
	}

	public Integer getIdFonteDadosEstadoCivil() {
		return idFonteDadosEstadoCivil;
	}

	public void setIdFonteDadosEstadoCivil(Integer idFonteDadosEstadoCivil) {
		this.idFonteDadosEstadoCivil = idFonteDadosEstadoCivil;
	}

	public Integer getIdFonteDadosDataNascimento() {
		return idFonteDadosDataNascimento;
	}

	public void setIdFonteDadosDataNascimento(Integer idFonteDadosDataNascimento) {
		this.idFonteDadosDataNascimento = idFonteDadosDataNascimento;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

}
