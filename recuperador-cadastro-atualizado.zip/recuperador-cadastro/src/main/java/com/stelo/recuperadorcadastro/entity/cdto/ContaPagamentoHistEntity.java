package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_CTA_PGTO_HIST", schema = "USR_CADU")
public class ContaPagamentoHistEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;

	@Column(name = "ID_CTA")
	private Long idConta;

	@Column(name = "DIA_MES_COBR_TARIF")
	private Integer diaMesCobrancaTarifa;

	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DT_CAD")
	private Date dtCadastro;

	@Column(name = "DT_INCL")
	private Date dtInclusao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DT_VCTO_ISENC_TARIF")
	private Date dtVecimentoIsencaoTarifa;

	@Column(name = "ID_PGTO_CTA")
	private String idPgtoConta;

	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;

	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;

	@Column(name = "NU_GRP_CTBIL")
	private String nuGrupoContabil;

	@Column(name = "ID_PER_COBR_TARIF")
	private Integer periodoCobrancaTarifa;

	@Column(name = "STTUS")
	private Integer status;

	@Column(name = "TARIF_ANIV")
	private Integer tarifaAniversario;

	@Column(name = "TARIF_CAD")
	private Integer tarifaCadastro;

	@Column(name = "TARIF_CTA_PGTO")
	private Integer tarifaContaPgto;

	@Column(name = "ID_MOTVO_BLOQ_CTA_PGTO")
	private Integer idMotivoBloqueioContaPgtoDm;
	
	@Column(name = "PCOTE_TARIF")
	private String pacoteTarifa;

	public Long getIdConta() {
		return idConta;
	}

	public void setIdConta(Long idConta) {
		this.idConta = idConta;
	}

	public Integer getDiaMesCobrancaTarifa() {
		return diaMesCobrancaTarifa;
	}

	public void setDiaMesCobrancaTarifa(Integer diaMesCobrancaTarifa) {
		this.diaMesCobrancaTarifa = diaMesCobrancaTarifa;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtCadastro() {
		return dtCadastro;
	}

	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public Date getDtVecimentoIsencaoTarifa() {
		return dtVecimentoIsencaoTarifa;
	}

	public void setDtVecimentoIsencaoTarifa(Date dtVecimentoIsencaoTarifa) {
		this.dtVecimentoIsencaoTarifa = dtVecimentoIsencaoTarifa;
	}

	public String getIdPgtoConta() {
		return idPgtoConta;
	}

	public void setIdPgtoConta(String idPgtoConta) {
		this.idPgtoConta = idPgtoConta;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public String getNuGrupoContabil() {
		return nuGrupoContabil;
	}

	public void setNuGrupoContabil(String nuGrupoContabil) {
		this.nuGrupoContabil = nuGrupoContabil;
	}

	public Integer getPeriodoCobrancaTarifa() {
		return periodoCobrancaTarifa;
	}

	public void setPeriodoCobrancaTarifa(Integer periodoCobrancaTarifa) {
		this.periodoCobrancaTarifa = periodoCobrancaTarifa;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getTarifaAniversario() {
		return tarifaAniversario;
	}

	public void setTarifaAniversario(Integer tarifaAniversario) {
		this.tarifaAniversario = tarifaAniversario;
	}

	public Integer getTarifaCadastro() {
		return tarifaCadastro;
	}

	public void setTarifaCadastro(Integer tarifaCadastro) {
		this.tarifaCadastro = tarifaCadastro;
	}

	public Integer getTarifaContaPgto() {
		return tarifaContaPgto;
	}

	public void setTarifaContaPgto(Integer tarifaContaPgto) {
		this.tarifaContaPgto = tarifaContaPgto;
	}

	public Integer getIdMotivoBloqueioContaPgtoDm() {
		return idMotivoBloqueioContaPgtoDm;
	}

	public void setIdMotivoBloqueioContaPgtoDm(Integer idMotivoBloqueioContaPgtoDm) {
		this.idMotivoBloqueioContaPgtoDm = idMotivoBloqueioContaPgtoDm;
	}

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

	public String getPacoteTarifa() {
		return pacoteTarifa;
	}

	public void setPacoteTarifa(String pacoteTarifa) {
		this.pacoteTarifa = pacoteTarifa;
	}
	
	


}
