package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.stelo.recuperadorcadastro.entity.cdto.ContaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EmailEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EmailHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EnderecoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EnderecoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteEntity;
import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TelefoneEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TelefoneHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TerminalEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TerminalHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaPagamentoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaPagamentoRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.ContaRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EcHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EcRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EmailHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EmailRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EnderecoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EnderecoRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.MaquinaCartaoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.MaquinaCartaoRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaFisicaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaFisicaRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRelacionamentoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRelacionamentoRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.SubAdquirenteHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.SubAdquirenteRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TelefoneHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TelefoneRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TerminalHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TerminalRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.utils.Conversor;

@Service
public class RecuperarCPFService {
	
	@Autowired
	private PessoaRepository pessoaRepository;
	
	@Autowired
	private PessoaHistRepository pessoaHistRepository;
	
	@Autowired
	private PessoaFisicaRepository pessoaFisicaRepository;
	
	@Autowired
	private PessoaFisicaHistRepository pessoaFisicaHistRepository;
	
	@Autowired
	private EcRepository ecRepository;
	
	@Autowired
	private EcHistRepository ecHistRepository;
	
	@Autowired
	private PessoaRelacionamentoRepository pessoaRelacionamentoRepository;
	
	@Autowired
	private PessoaRelacionamentoHistRepository pessoaRelacionamentoHistRepository;
	
	@Autowired
	private SubAdquirenteRepository  subAdquirenteRepository;
	
	@Autowired
	private SubAdquirenteHistRepository subAdquirenteHistRepository;
	
	@Autowired
	private TerminalRepository terminalRepository;
	
	@Autowired
	private TerminalHistRepository terminalHistRepository;
	
	@Autowired
	private MaquinaCartaoRepository maquinaCartaoRepository;
	
	@Autowired
	private MaquinaCartaoHistRepository maquinaCartaoHistRepository;
	
	@Autowired
	private ContaRepository contaRepository;
	
	@Autowired
	private ContaHistRepository contaHistRepository;
	
	@Autowired
	private ContaPagamentoRepository contaPagamentoRepository;
	
	@Autowired
	private ContaPagamentoHistRepository contaPagamentoHistRepository;
	
	@Autowired
	private EmailRepository emailRepository;
	
	@Autowired
	private EmailHistRepository emailHistRepository;
	
	@Autowired
	private EnderecoRepository enderecoRepository;
	
	@Autowired
	private EnderecoHistRepository enderecoHistRepository;
	
	@Autowired
	private TelefoneRepository telefoneRepository;
	
	@Autowired
	private TelefoneHistRepository telefoneHistRepository;
	
	private Conversor conversor = new Conversor();
	
	public void buscarDadosHistorico(String idStelo) {
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaHistEntity> listaPessoaHist = 
				pessoaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<PessoaFisicaHistEntity> listaPessoaFisicaHist = 
				pessoaFisicaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<EcHistEntity> listaEcHist = 
				ecHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<PessoaRelacionamentoHistEntity> listaRelacionamentoHist =
				pessoaRelacionamentoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<SubAdquirenteHistEntity> listaSubAdquirenteHist = 
				subAdquirenteHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<TerminalHistEntity> listaTerminalHist = 
				terminalHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<MaquinaCartaoHistEntity> listaMaquinaCartaoHist = 
				maquinaCartaoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<ContaHistEntity> listaContaHist = 
				contaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<ContaPagamentoHistEntity> listaContaPagamentoHist = 
				contaPagamentoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<EmailHistEntity> listaEmailHist = 
				emailHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<EnderecoHistEntity> listaEnderecoHist = 
				enderecoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		List<TelefoneHistEntity> listaTelefoneHist = 
				telefoneHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
	}
	
	public void salvar(PessoaHistEntity pessoaHistEntity, PessoaFisicaHistEntity pessoaFisicaHistEntity,
			EcHistEntity ecHistEntity, PessoaRelacionamentoHistEntity pessoaRelacionamentoHistEntity, 
			SubAdquirenteHistEntity subAdquirenteHistEntity, List<TerminalHistEntity> terminaisHistEntity, 
			MaquinaCartaoHistEntity maquinaCartaoHistEntity, List<ContaHistEntity> contasHistEntity,
			ContaPagamentoHistEntity contaPagamentoHistEntity, EmailHistEntity emailHistEntity,
			EnderecoHistEntity enderecoHistEntity, List<TelefoneHistEntity> telefonesHistEntity) {
		
//		PessoaEntity pessoaEntity = conversor.construirPessoa(pessoaHistEntity);
//		PessoaFisicaEntity pessoaFisicaEntity = conversor.construirPessoaFisica(pessoaFisicaHistEntity);
//		EcEntity ecEntity = conversor.construirEc(ecHistEntity);
//		PessoaRelacionamentoEntity relacionamentoEntity = conversor.construirPesoaRelacionamento(pessoaRelacionamentoHistEntity);
//		SubAdquirenteEntity subAdquirenteEntity = conversor.construirSubAdquirente(subAdquirenteHistEntity);
//		List<TerminalEntity> terminaisEntity = conversor.construirTerminais(terminaisHistEntity);
//		MaquinaCartaoEntity maquinaCartaoEntity = conversor.construirMaquinaCartao(maquinaCartaoHistEntity);
//		List<ContaEntity> contasEntity = conversor.construirContas(contasHistEntity);
//		ContaPagamentoEntity contaPagamentoEntity = conversor.construirContaPagamento(contaPagamentoHistEntity);
//		EmailEntity emailEntity = conversor.construirEmail(emailHistEntity);
//		EnderecoEntity enderecoEntity = conversor.construirEndereco(enderecoHistEntity);
//		List<TelefoneEntity> telefonesEntity = conversor.construirTelefones(telefonesHistEntity);
//		
//		pessoaRepository.save(pessoaEntity);
//		pessoaFisicaRepository.save(pessoaFisicaEntity);
//		ecRepository.save(ecEntity);
//		pessoaRelacionamentoRepository.save(relacionamentoEntity);
//		subAdquirenteRepository.save(subAdquirenteEntity);
//		terminalRepository.saveAll(terminaisEntity);
//		maquinaCartaoRepository.save(maquinaCartaoEntity);
//		contaRepository.saveAll(contasEntity);
//		contaPagamentoRepository.save(contaPagamentoEntity);
//		emailRepository.save(emailEntity);
//		enderecoRepository.save(enderecoEntity);
//		telefoneRepository.saveAll(telefonesEntity);
	}

}
