package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_PSSOA", schema = "USR_CADU")
@Inheritance(strategy = InheritanceType.JOINED)
public class PessoaEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SeqPessoaGenerator", sequenceName = "SQ_PSSOA", allocationSize = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqPessoaGenerator")
	@Column(name = "ID_STELO", nullable = false)
	private Long idStelo;

	@Column(name = "APLDO")
	private String apelido;

	// @Temporal(TemporalType.DATE)
	@Column(name = "DT_ALT")
	private Date dtAlteracaoPessoa;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DT_CAD_CTA_STELO")
	private Date dtCadastroContaStelo;

	// @Temporal(TemporalType.DATE)
	@Column(name = "DT_INCL")
	private Date dtInclusaoPessoa;

	@Column(name = "USUAR_ALT")
	private String usuarioAlteracaoPessoa;

	@Column(name = "USUAR_INCL")
	private String usuarioInclusaoPessoa;

	@Column(name = "STTUS")
	private Integer status;

	@Column(name = "ID_VIP")
	private Integer idVip;

	@Column(name = "TP_PSSOA")
	private Character tpPessoa;

	@Column(name = "ID_CANAL_ORIGE")
	private Integer idCanalOrigem;

	@Column(name = "ID_MOTVO_BLOQ_PSSOA")
	private Integer idMotivoBloqueoPessoa;

	@Column(name = "ID_STTUS_CAD_USUAR")
	private Integer idStatusCadastroUsuario;

	@Column(name = "FLG_CAD_INCPL")
	private Character flagCadastroIncompleto;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public Date getDtAlteracaoPessoa() {
		return dtAlteracaoPessoa;
	}

	public void setDtAlteracaoPessoa(Date dtAlteracaoPessoa) {
		this.dtAlteracaoPessoa = dtAlteracaoPessoa;
	}

	public Date getDtCadastroContaStelo() {
		return dtCadastroContaStelo;
	}

	public void setDtCadastroContaStelo(Date dtCadastroContaStelo) {
		this.dtCadastroContaStelo = dtCadastroContaStelo;
	}

	public Date getDtInclusaoPessoa() {
		return dtInclusaoPessoa;
	}

	public void setDtInclusaoPessoa(Date dtInclusaoPessoa) {
		this.dtInclusaoPessoa = dtInclusaoPessoa;
	}

	public String getUsuarioAlteracaoPessoa() {
		return usuarioAlteracaoPessoa;
	}

	public void setUsuarioAlteracaoPessoa(String usuarioAlteracaoPessoa) {
		this.usuarioAlteracaoPessoa = usuarioAlteracaoPessoa;
	}

	public String getUsuarioInclusaoPessoa() {
		return usuarioInclusaoPessoa;
	}

	public void setUsuarioInclusaoPessoa(String usuarioInclusaoPessoa) {
		this.usuarioInclusaoPessoa = usuarioInclusaoPessoa;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIdVip() {
		return idVip;
	}

	public void setIdVip(Integer idVip) {
		this.idVip = idVip;
	}

	public Character getTpPessoa() {
		return tpPessoa;
	}

	public void setTpPessoa(Character tpPessoa) {
		this.tpPessoa = tpPessoa;
	}

	public Integer getIdCanalOrigem() {
		return idCanalOrigem;
	}

	public void setIdCanalOrigem(Integer idCanalOrigem) {
		this.idCanalOrigem = idCanalOrigem;
	}

	public Integer getIdMotivoBloqueoPessoa() {
		return idMotivoBloqueoPessoa;
	}

	public void setIdMotivoBloqueoPessoa(Integer idMotivoBloqueoPessoa) {
		this.idMotivoBloqueoPessoa = idMotivoBloqueoPessoa;
	}

	public Integer getIdStatusCadastroUsuario() {
		return idStatusCadastroUsuario;
	}

	public void setIdStatusCadastroUsuario(Integer idStatusCadastroUsuario) {
		this.idStatusCadastroUsuario = idStatusCadastroUsuario;
	}

	public Character getFlagCadastroIncompleto() {
		return flagCadastroIncompleto;
	}

	public void setFlagCadastroIncompleto(Character flagCadastroIncompleto) {
		this.flagCadastroIncompleto = flagCadastroIncompleto;
	}

}
