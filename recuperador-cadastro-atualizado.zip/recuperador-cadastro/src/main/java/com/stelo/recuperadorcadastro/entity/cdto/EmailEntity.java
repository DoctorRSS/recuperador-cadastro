package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_EMAIL", schema = "USR_CADU")
public class EmailEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_EMAIL", nullable = false)
	private Long idEmail;

	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Column(name = "DT_INCL")
	private Date dtInclusao;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;

	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;

	@Column(name = "STTUS")
	private Integer status;

	@Column(name = "ID_TP_EMAIL")
	private Integer idTpEmail;

	@Column(name = "ID_FONTE_DADOS_EMAIL")
	private Integer idFonteDadosEmailDm;

	@Column(name = "ID_CANAL_ORIGE")
	private Integer idCanalOrigem;
	
	@Column(name = "ID_RLCTO")
	private Integer idRelacionamento;
	
	public EmailEntity() {
		super();
	}

	public Long getIdEmail() {
		return idEmail;
	}

	public void setIdEmail(Long idEmail) {
		this.idEmail = idEmail;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIdTpEmail() {
		return idTpEmail;
	}

	public void setIdTpEmail(Integer idTpEmail) {
		this.idTpEmail = idTpEmail;
	}

	public Integer getIdFonteDadosEmailDm() {
		return idFonteDadosEmailDm;
	}

	public void setIdFonteDadosEmailDm(Integer idFonteDadosEmailDm) {
		this.idFonteDadosEmailDm = idFonteDadosEmailDm;
	}

	public Integer getIdCanalOrigem() {
		return idCanalOrigem;
	}

	public void setIdCanalOrigem(Integer idCanalOrigem) {
		this.idCanalOrigem = idCanalOrigem;
	}

	public Integer getIdRelacionamento() {
		return idRelacionamento;
	}

	public void setIdRelacionamento(Integer idRelacionamento) {
		this.idRelacionamento = idRelacionamento;
	}

}
