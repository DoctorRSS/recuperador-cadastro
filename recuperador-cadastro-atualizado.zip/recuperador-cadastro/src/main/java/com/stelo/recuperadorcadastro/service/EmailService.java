package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.EmailEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EmailHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EmailHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EmailRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class EmailService {

	@Autowired
	private EmailHistRepository emailHistRepository;
	
	@Autowired
	private EmailRepository emailRepository;
	
	public EmailService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<EmailHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<EmailHistEntity> listaEmailHist =
				emailHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaEmailHist;
	}
	
	@PutMapping
	public void salvar(EmailHistEntity emailHistEntity) throws ObjetoNuloException {
		EmailEntity emailEntity;
		try {
			emailEntity = construirEmail(emailHistEntity);
			emailRepository.save(emailEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private EmailEntity construirEmail(EmailHistEntity emailHistEntity) throws ObjetoNuloException {
		EmailEntity emailEntity = new EmailEntity();
		
		if(emailHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de email para Alteração!");
			
		emailEntity.setDtAlteracao(emailHistEntity.getDtAlteracao());
		emailEntity.setDtInclusao(emailHistEntity.getDtInclusao());
		emailEntity.setEmail(emailHistEntity.getEmail());
		emailEntity.setIdCanalOrigem(emailHistEntity.getIdCanalOrigem());
		emailEntity.setIdEmail(emailHistEntity.getIdEmail());
		emailEntity.setIdFonteDadosEmailDm(emailHistEntity.getIdFonteDadosEmailDm());
		emailEntity.setIdRelacionamento(emailHistEntity.getIdRelacionamento());
		emailEntity.setIdTpEmail(emailHistEntity.getIdTpEmail());
		emailEntity.setIdUsuarioAlteracao(emailHistEntity.getIdUsuarioAlteracao());
		emailEntity.setIdUsuarioInclusao(emailHistEntity.getIdUsuarioInclusao());
		emailEntity.setStatus(emailHistEntity.getStatus());
		
		return emailEntity;
	}

}
